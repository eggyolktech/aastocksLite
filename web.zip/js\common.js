
var tfPeriod = {
    list:[{"timeframe": "M", "period": "2060"}, {"timeframe": "W", "period": "11"}, {"timeframe": "D", "period": "9"}, {"timeframe": "h", "period": "5023"}, {"timeframe": "m", "period": "5012"}]
}

var tfCNPeriod = {
    list:[{"timeframe": "M", "period": "54"}, {"timeframe": "W", "period": "11"}, {"timeframe": "D", "period": "9"}, {"timeframe": "h", "period": "5023"}, {"timeframe": "m", "period": "5012"}]
}

var tfUSPeriod = {
    list:[{"timeframe": "M", "period": "54"}, {"timeframe": "W", "period": "11"}, {"timeframe": "D", "period": "9"}, {"timeframe": "h", "period": "4"}, {"timeframe": "m", "period": "0"}]
}

var CAPTION_SELECT = "請選擇";
var CAPTION_SELECT_EN = "Please Select";